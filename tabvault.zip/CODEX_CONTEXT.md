# tabvault Codex Context

Purpose: Extract and organise Notepad++ backup tabs safely into structured folders.

Safety requirement: NEVER modify or delete original backup files.

Future features:
- session.xml parsing
- search
- tagging
- CLI interface
