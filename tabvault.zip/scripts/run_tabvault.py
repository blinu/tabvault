from tabvault.organiser import run

run()
