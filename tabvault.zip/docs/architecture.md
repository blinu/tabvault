# Architecture

Notepad++ backup → extract → classify → organise → output

Safety-first: originals never modified.
